﻿namespace AppTabla
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnum1 = new System.Windows.Forms.TextBox();
            this.txtnum2 = new System.Windows.Forms.TextBox();
            this.txtfila1 = new System.Windows.Forms.TextBox();
            this.txtnum3 = new System.Windows.Forms.TextBox();
            this.txtfila2 = new System.Windows.Forms.TextBox();
            this.txtfila3 = new System.Windows.Forms.TextBox();
            this.txtnum6 = new System.Windows.Forms.TextBox();
            this.txtnum5 = new System.Windows.Forms.TextBox();
            this.txtnum4 = new System.Windows.Forms.TextBox();
            this.txtnum12 = new System.Windows.Forms.TextBox();
            this.txtnum11 = new System.Windows.Forms.TextBox();
            this.txtnum10 = new System.Windows.Forms.TextBox();
            this.txtnum9 = new System.Windows.Forms.TextBox();
            this.txtnum8 = new System.Windows.Forms.TextBox();
            this.txtnum7 = new System.Windows.Forms.TextBox();
            this.txtnum15 = new System.Windows.Forms.TextBox();
            this.txtnum14 = new System.Windows.Forms.TextBox();
            this.txtnum13 = new System.Windows.Forms.TextBox();
            this.txtfila4 = new System.Windows.Forms.TextBox();
            this.txtfila5 = new System.Windows.Forms.TextBox();
            this.txtcolumna1 = new System.Windows.Forms.TextBox();
            this.txtcolumna2 = new System.Windows.Forms.TextBox();
            this.txtcolumna3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limpiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtnum1
            // 
            this.txtnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum1.Location = new System.Drawing.Point(96, 116);
            this.txtnum1.Name = "txtnum1";
            this.txtnum1.Size = new System.Drawing.Size(100, 40);
            this.txtnum1.TabIndex = 0;
            this.txtnum1.Text = "0";
            this.txtnum1.TextChanged += new System.EventHandler(this.txtnum1_TextChanged);
            // 
            // txtnum2
            // 
            this.txtnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum2.Location = new System.Drawing.Point(192, 116);
            this.txtnum2.Name = "txtnum2";
            this.txtnum2.Size = new System.Drawing.Size(100, 40);
            this.txtnum2.TabIndex = 1;
            this.txtnum2.Text = "0";
            this.txtnum2.TextChanged += new System.EventHandler(this.txtnum2_TextChanged);
            // 
            // txtfila1
            // 
            this.txtfila1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfila1.Location = new System.Drawing.Point(416, 124);
            this.txtfila1.Name = "txtfila1";
            this.txtfila1.ReadOnly = true;
            this.txtfila1.Size = new System.Drawing.Size(100, 29);
            this.txtfila1.TabIndex = 2;
            this.txtfila1.Text = "0";
            this.txtfila1.TextChanged += new System.EventHandler(this.txtfila1_TextChanged);
            // 
            // txtnum3
            // 
            this.txtnum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum3.Location = new System.Drawing.Point(288, 116);
            this.txtnum3.Name = "txtnum3";
            this.txtnum3.Size = new System.Drawing.Size(100, 40);
            this.txtnum3.TabIndex = 3;
            this.txtnum3.Text = "0";
            this.txtnum3.TextChanged += new System.EventHandler(this.txtnum3_TextChanged);
            // 
            // txtfila2
            // 
            this.txtfila2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfila2.Location = new System.Drawing.Point(416, 159);
            this.txtfila2.Name = "txtfila2";
            this.txtfila2.ReadOnly = true;
            this.txtfila2.Size = new System.Drawing.Size(100, 29);
            this.txtfila2.TabIndex = 16;
            this.txtfila2.Text = "0";
            // 
            // txtfila3
            // 
            this.txtfila3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfila3.Location = new System.Drawing.Point(416, 194);
            this.txtfila3.Name = "txtfila3";
            this.txtfila3.ReadOnly = true;
            this.txtfila3.Size = new System.Drawing.Size(100, 29);
            this.txtfila3.TabIndex = 17;
            this.txtfila3.Text = "0";
            // 
            // txtnum6
            // 
            this.txtnum6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum6.Location = new System.Drawing.Point(288, 151);
            this.txtnum6.Name = "txtnum6";
            this.txtnum6.Size = new System.Drawing.Size(100, 40);
            this.txtnum6.TabIndex = 20;
            this.txtnum6.Text = "0";
            this.txtnum6.TextChanged += new System.EventHandler(this.txtnum6_TextChanged);
            // 
            // txtnum5
            // 
            this.txtnum5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum5.Location = new System.Drawing.Point(192, 151);
            this.txtnum5.Name = "txtnum5";
            this.txtnum5.Size = new System.Drawing.Size(100, 40);
            this.txtnum5.TabIndex = 19;
            this.txtnum5.Text = "0";
            this.txtnum5.TextChanged += new System.EventHandler(this.txtnum5_TextChanged);
            // 
            // txtnum4
            // 
            this.txtnum4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum4.Location = new System.Drawing.Point(96, 151);
            this.txtnum4.Name = "txtnum4";
            this.txtnum4.Size = new System.Drawing.Size(100, 40);
            this.txtnum4.TabIndex = 18;
            this.txtnum4.Text = "0";
            this.txtnum4.TextChanged += new System.EventHandler(this.txtnum4_TextChanged);
            // 
            // txtnum12
            // 
            this.txtnum12.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum12.Location = new System.Drawing.Point(288, 221);
            this.txtnum12.Name = "txtnum12";
            this.txtnum12.Size = new System.Drawing.Size(100, 40);
            this.txtnum12.TabIndex = 26;
            this.txtnum12.Text = "0";
            this.txtnum12.TextChanged += new System.EventHandler(this.txtnum12_TextChanged);
            // 
            // txtnum11
            // 
            this.txtnum11.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum11.Location = new System.Drawing.Point(192, 221);
            this.txtnum11.Name = "txtnum11";
            this.txtnum11.Size = new System.Drawing.Size(100, 40);
            this.txtnum11.TabIndex = 25;
            this.txtnum11.Text = "0";
            this.txtnum11.TextChanged += new System.EventHandler(this.txtnum11_TextChanged);
            // 
            // txtnum10
            // 
            this.txtnum10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum10.Location = new System.Drawing.Point(96, 221);
            this.txtnum10.Name = "txtnum10";
            this.txtnum10.Size = new System.Drawing.Size(100, 40);
            this.txtnum10.TabIndex = 24;
            this.txtnum10.Text = "0";
            this.txtnum10.TextChanged += new System.EventHandler(this.txtnum10_TextChanged);
            // 
            // txtnum9
            // 
            this.txtnum9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum9.Location = new System.Drawing.Point(288, 186);
            this.txtnum9.Name = "txtnum9";
            this.txtnum9.Size = new System.Drawing.Size(100, 40);
            this.txtnum9.TabIndex = 23;
            this.txtnum9.Text = "0";
            this.txtnum9.TextChanged += new System.EventHandler(this.txtnum9_TextChanged);
            // 
            // txtnum8
            // 
            this.txtnum8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum8.Location = new System.Drawing.Point(192, 186);
            this.txtnum8.Name = "txtnum8";
            this.txtnum8.Size = new System.Drawing.Size(100, 40);
            this.txtnum8.TabIndex = 22;
            this.txtnum8.Text = "0";
            this.txtnum8.TextChanged += new System.EventHandler(this.txtnum8_TextChanged);
            // 
            // txtnum7
            // 
            this.txtnum7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum7.Location = new System.Drawing.Point(96, 186);
            this.txtnum7.Name = "txtnum7";
            this.txtnum7.Size = new System.Drawing.Size(100, 40);
            this.txtnum7.TabIndex = 21;
            this.txtnum7.Text = "0";
            this.txtnum7.TextChanged += new System.EventHandler(this.txtnum7_TextChanged);
            // 
            // txtnum15
            // 
            this.txtnum15.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum15.Location = new System.Drawing.Point(288, 255);
            this.txtnum15.Name = "txtnum15";
            this.txtnum15.Size = new System.Drawing.Size(100, 40);
            this.txtnum15.TabIndex = 29;
            this.txtnum15.Text = "0";
            this.txtnum15.TextChanged += new System.EventHandler(this.txtnum15_TextChanged);
            // 
            // txtnum14
            // 
            this.txtnum14.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum14.Location = new System.Drawing.Point(192, 255);
            this.txtnum14.Name = "txtnum14";
            this.txtnum14.Size = new System.Drawing.Size(100, 40);
            this.txtnum14.TabIndex = 28;
            this.txtnum14.Text = "0";
            this.txtnum14.TextChanged += new System.EventHandler(this.txtnum14_TextChanged);
            // 
            // txtnum13
            // 
            this.txtnum13.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum13.Location = new System.Drawing.Point(96, 255);
            this.txtnum13.Name = "txtnum13";
            this.txtnum13.Size = new System.Drawing.Size(100, 40);
            this.txtnum13.TabIndex = 27;
            this.txtnum13.Text = "0";
            this.txtnum13.TextChanged += new System.EventHandler(this.txtnum13_TextChanged);
            // 
            // txtfila4
            // 
            this.txtfila4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfila4.Location = new System.Drawing.Point(416, 229);
            this.txtfila4.Name = "txtfila4";
            this.txtfila4.ReadOnly = true;
            this.txtfila4.Size = new System.Drawing.Size(100, 29);
            this.txtfila4.TabIndex = 30;
            this.txtfila4.Text = "0";
            // 
            // txtfila5
            // 
            this.txtfila5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfila5.Location = new System.Drawing.Point(416, 264);
            this.txtfila5.Name = "txtfila5";
            this.txtfila5.ReadOnly = true;
            this.txtfila5.Size = new System.Drawing.Size(100, 29);
            this.txtfila5.TabIndex = 31;
            this.txtfila5.Text = "0";
            // 
            // txtcolumna1
            // 
            this.txtcolumna1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcolumna1.Location = new System.Drawing.Point(96, 312);
            this.txtcolumna1.Name = "txtcolumna1";
            this.txtcolumna1.ReadOnly = true;
            this.txtcolumna1.Size = new System.Drawing.Size(100, 29);
            this.txtcolumna1.TabIndex = 32;
            this.txtcolumna1.Text = "0";
            // 
            // txtcolumna2
            // 
            this.txtcolumna2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcolumna2.Location = new System.Drawing.Point(192, 312);
            this.txtcolumna2.Name = "txtcolumna2";
            this.txtcolumna2.ReadOnly = true;
            this.txtcolumna2.Size = new System.Drawing.Size(100, 29);
            this.txtcolumna2.TabIndex = 33;
            this.txtcolumna2.Text = "0";
            // 
            // txtcolumna3
            // 
            this.txtcolumna3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcolumna3.Location = new System.Drawing.Point(288, 312);
            this.txtcolumna3.Name = "txtcolumna3";
            this.txtcolumna3.ReadOnly = true;
            this.txtcolumna3.Size = new System.Drawing.Size(100, 29);
            this.txtcolumna3.TabIndex = 34;
            this.txtcolumna3.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(537, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 24);
            this.label1.TabIndex = 35;
            this.label1.Text = "Fila 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(537, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 24);
            this.label2.TabIndex = 36;
            this.label2.Text = "Fila 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(537, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 24);
            this.label3.TabIndex = 37;
            this.label3.Text = "Fila 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(537, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 24);
            this.label4.TabIndex = 38;
            this.label4.Text = "Fila 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(537, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 24);
            this.label5.TabIndex = 39;
            this.label5.Text = "Fila 5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(86, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 24);
            this.label6.TabIndex = 40;
            this.label6.Text = "Columna 1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(188, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 24);
            this.label7.TabIndex = 41;
            this.label7.Text = "Columna 2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(293, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 24);
            this.label8.TabIndex = 42;
            this.label8.Text = "Columna 3";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inicioToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 43;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.limpiarToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.inicioToolStripMenuItem.Text = "Inicio";
            // 
            // limpiarToolStripMenuItem
            // 
            this.limpiarToolStripMenuItem.Name = "limpiarToolStripMenuItem";
            this.limpiarToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.limpiarToolStripMenuItem.Text = "Limpiar";
            this.limpiarToolStripMenuItem.Click += new System.EventHandler(this.limpiarToolStripMenuItem_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtcolumna3);
            this.Controls.Add(this.txtcolumna2);
            this.Controls.Add(this.txtcolumna1);
            this.Controls.Add(this.txtfila5);
            this.Controls.Add(this.txtfila4);
            this.Controls.Add(this.txtnum15);
            this.Controls.Add(this.txtnum14);
            this.Controls.Add(this.txtnum13);
            this.Controls.Add(this.txtnum12);
            this.Controls.Add(this.txtnum11);
            this.Controls.Add(this.txtnum10);
            this.Controls.Add(this.txtnum9);
            this.Controls.Add(this.txtnum8);
            this.Controls.Add(this.txtnum7);
            this.Controls.Add(this.txtnum6);
            this.Controls.Add(this.txtnum5);
            this.Controls.Add(this.txtnum4);
            this.Controls.Add(this.txtfila3);
            this.Controls.Add(this.txtfila2);
            this.Controls.Add(this.txtnum3);
            this.Controls.Add(this.txtfila1);
            this.Controls.Add(this.txtnum2);
            this.Controls.Add(this.txtnum1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnum1;
        private System.Windows.Forms.TextBox txtnum2;
        private System.Windows.Forms.TextBox txtfila1;
        private System.Windows.Forms.TextBox txtnum3;
        private System.Windows.Forms.TextBox txtfila2;
        private System.Windows.Forms.TextBox txtfila3;
        private System.Windows.Forms.TextBox txtnum6;
        private System.Windows.Forms.TextBox txtnum5;
        private System.Windows.Forms.TextBox txtnum4;
        private System.Windows.Forms.TextBox txtnum12;
        private System.Windows.Forms.TextBox txtnum11;
        private System.Windows.Forms.TextBox txtnum10;
        private System.Windows.Forms.TextBox txtnum9;
        private System.Windows.Forms.TextBox txtnum8;
        private System.Windows.Forms.TextBox txtnum7;
        private System.Windows.Forms.TextBox txtnum15;
        private System.Windows.Forms.TextBox txtnum14;
        private System.Windows.Forms.TextBox txtnum13;
        private System.Windows.Forms.TextBox txtfila4;
        private System.Windows.Forms.TextBox txtfila5;
        private System.Windows.Forms.TextBox txtcolumna1;
        private System.Windows.Forms.TextBox txtcolumna2;
        private System.Windows.Forms.TextBox txtcolumna3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limpiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
    }
}

